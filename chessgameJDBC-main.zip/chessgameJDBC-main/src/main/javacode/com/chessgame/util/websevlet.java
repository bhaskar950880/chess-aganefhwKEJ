package com.chessgame.util;

public @interface websevlet {

}
